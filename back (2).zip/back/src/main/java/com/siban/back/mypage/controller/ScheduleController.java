package com.siban.back.mypage.controller;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class ScheduleController {

}
