package com.siban.back.board.repository;

public interface ReplyRepository {

}
