package com.siban.back.board.service;

import com.siban.back.board.repository.ReplyRepository;

public class ReplyService implements ReplyRepository {

}
